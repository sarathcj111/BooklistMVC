﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO.Enumeration;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using TestMVC.Helper;
using TestMVC.Models;
using TestMVC.Repository.Interface;

namespace TestMVC.Repository
{
    public class CompanyRepository : ICompanyRepository
    {
        private readonly IConfiguration _config;
        private HelperClass _helper;
        public CompanyRepository(IConfiguration config)
        {
            _config = config;
            _helper = new HelperClass();
        }
        //private List<CompanyModel> CompanyList = new List<CompanyModel>();

        private List<CompanyModel> GenerateCompanyList()
        {
            var companyList = new List<CompanyModel>();
            for (var i = 0; i <= 100; i++)
            {
                if(_config.GetValue<int>($"Company{i + 1}:Id") > 0)
                {
                    CompanyModel Company = new CompanyModel();
                    Company.Id = _config.GetValue<int>($"Company{i + 1}:Id");
                    Company.Name = _config.GetValue<string>($"Company{i + 1}:Name");
                    Company.City = _config.GetValue<string>($"Company{i + 1}:City");
                    companyList.Add(Company);
                }
                else
                    break;
            }
            return companyList;
        }
        public List<CompanyModel> AddNewCompany(CompanyModel Company)
        {
            var Companys = GenerateCompanyList();
            Company.Id = Companys.Count + 1;
            Companys.Add(Company);
            _helper.AddtoJson(Company);
            return Companys;
        }


        public async Task<bool> AddNewCompanyAsync(CompanyModel Company)
        {
            var Companys = GenerateCompanyList();
            Company.Id = Companys.Count + 1;
            Companys.Add(Company);

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44329");

                string json = JsonConvert.SerializeObject(Company);

                StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                var result = await client.PostAsync("CompanyTest/addCompany", httpContent);

                if (result.IsSuccessStatusCode)
                {
                    return true;
                }
                else
                {
                    throw new Exception("Server error try after some time.");
                }
            }
        }
        public List<CompanyModel> GetAllCompanys()
        {
            var companyList = GenerateCompanyList();
            return companyList;
        }

        public async Task<List<CompanyModel>> GetAllCompaniesFromApi()
        {
            List<CompanyModel> companies = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44329");

                var result = await client.GetAsync("CompanyTest/getAllCompanies");

                if (result.IsSuccessStatusCode)
                {
                    companies = JsonConvert.DeserializeObject<List<CompanyModel>>(await result.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new Exception("Server error. try after some time.");
                }
            }
            return companies;
        }

        //public List<CompanyModel> EditCompany(int CompanyId)
        //{
        //    var Companys = GenerateCompanyList();
        //    var Company = Companys.Find(x => x.Id == CompanyId);
        //    Company.Name = "edited " + Company.Name;
        //    return Companys;
        //}
        public List<CompanyModel> EditCompany(CompanyModel company)
        {
            var Companys = GenerateCompanyList();
            var Company = Companys.Find(x => x.Id == company.Id);
            Companys.Remove(company);
            _helper.RemoveFromJson(Company.Id, "Company");
            Companys.Add(company);
            _helper.AddtoJson(Company);
            return Companys;
        }

        public async Task<List<CompanyModel>> EditCompanyAsync(CompanyModel company)
        {
            var Companys = GenerateCompanyList();
            var Company = Companys.Find(x => x.Id == company.Id);
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44329");

                string json = JsonConvert.SerializeObject(company);

                StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                var result = await client.PutAsync("CompanyTest/editCompany", httpContent);

                if (result.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<List<CompanyModel>>(await result.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new Exception("Server error try after some time.");
                }
            }
        }
        public bool DeleteCompany(int CompanyId, out List<CompanyModel> Companys)
        {
            Companys = GenerateCompanyList();
            Companys.Remove(Companys.Find(x => x.Id == CompanyId));
            var Company = Companys.Find(x => x.Id == CompanyId);
            if (Company == null)
            {
                _helper.RemoveFromJson(CompanyId, "Company");
                return true;
            }
            else
                return false;
        }

        public async Task<List<CompanyModel>> DeleteCompanyAsync(int companyId)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44329");

                // https://localhost:44329/Test/deleteBook?bookid=5&companyId=1

                var result = await client.DeleteAsync($"CompanyTest/deleteCompany?companyId={companyId}");

                if (result.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<List<CompanyModel>>(await result.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new Exception("Server error try after some time.");
                }
            }
        }

        public CompanyModel SearchCompany(int CompanyId)
        {
            var Companys = GenerateCompanyList();
            var Company = Companys.Find(x => x.Id == CompanyId);
            return Company;
        }

        public IEnumerable<CompanyModel> SearchLikeCompany(string company)
        {
            var Companys = GenerateCompanyList();
            var Company = Companys.Where(s => s.Name.Contains(company));
            return Company;
        }

        public IEnumerable<CompanyModel> SearchLikePatternCompany(string pattern)
        {
            var Companys = GenerateCompanyList();
            var Company = Companys.Where(s => FileSystemName.MatchesSimpleExpression(pattern, s.Name));
            return Company;
        }
    }
}

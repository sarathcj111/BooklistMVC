﻿using Microsoft.AspNetCore.Mvc;

namespace TestMVC.Controllers
{
    public class AuthController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}

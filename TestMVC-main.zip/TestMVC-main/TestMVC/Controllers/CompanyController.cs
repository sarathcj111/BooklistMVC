﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using TestMVC.Models;
using TestMVC.Repository.Interface;

namespace TestMVC.Controllers
{
    public class CompanyController : Controller
    {
        private readonly ILogger<CompanyController> _logger;
        private readonly ICompanyRepository _ICompanyRepository;
        public CompanyController(ILogger<CompanyController> logger, ICompanyRepository iCompanyRepository)
        {
            _logger = logger;
            _ICompanyRepository = iCompanyRepository;
        }
        public async Task<IActionResult> Index()
        {
            //var books = _IBookRepository.GetAllBooks();
            try
            {
                var books = await _ICompanyRepository.GetAllCompaniesFromApi();
                return View(books);
            }
            catch (Exception ex)
            {
                return View("Error", new ErrorViewModel { RequestId = ex.Message ?? HttpContext.TraceIdentifier });
            }
            //return View(books);
        }

        public IActionResult OpenEditCompanyPage(int companyId)
        {
            var company = _ICompanyRepository.SearchCompany(companyId);
            var companyLike = _ICompanyRepository.SearchLikeCompany("com");
            var companyPattern = _ICompanyRepository.SearchLikeCompany("com*");

            List<SelectListItem> Cities = new List<SelectListItem>()
            {
                new SelectListItem() { Value="Kolkata", Text="Kolkata" },
                new SelectListItem() { Value="Chennai", Text="Chennai" },
                new SelectListItem() { Value="Banglore", Text="Banglore" },
                new SelectListItem() { Value="Delhi", Text="Delhi" }
            };

            ViewBag.Cities = Cities;

            return View("EditCompany", company);
        }

        public async Task<IActionResult> EditCompany(CompanyModel company)
        {
            try
            {
                var companies = await _ICompanyRepository.EditCompanyAsync(company);
                return View("Index", companies);
            }
            catch (Exception ex)
            {
                return View("Error", new ErrorViewModel { RequestId = ex.Message ?? HttpContext.TraceIdentifier });
            }
        }

        public async Task<IActionResult> DeleteCompany(int companyId)
        {
            try
            {
                var companies = await _ICompanyRepository.DeleteCompanyAsync(companyId);
                return View("Index", companies);
            }
            catch (Exception ex)
            {

                return View("Error", new ErrorViewModel { RequestId = ex.Message ?? HttpContext.TraceIdentifier });
            }
        }

        public IActionResult OpenAddCompanyPage()
        {
            List<SelectListItem> Cities = new List<SelectListItem>()
            {
                new SelectListItem() { Value="Kolkata", Text="Kolkata" },
                new SelectListItem() { Value="Chennai", Text="Chennai" },
                new SelectListItem() { Value="Banglore", Text="Banglore" },
                new SelectListItem() { Value="Delhi", Text="Delhi" }
            };

            ViewBag.CityList = Cities;
            return View("AddCompany");
        }

        public async Task<IActionResult> AddCompany(CompanyModel company)
        {
            try
            {
                var isAdded = await _ICompanyRepository.AddNewCompanyAsync(company);
                if (isAdded)
                {
                    var companies = await _ICompanyRepository.GetAllCompaniesFromApi();
                    return View("Index", companies);
                }
                else
                {
                    return View("Error", new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
                }
            }
            catch (Exception ex)
            {
                return View("Error", new ErrorViewModel { RequestId = ex.Message ?? HttpContext.TraceIdentifier });
            }
        }
    }
}
